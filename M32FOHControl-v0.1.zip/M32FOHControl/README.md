# M32 FOH Control v0.1

Native Android Kotlin app for Midas M32/M32R. OSC over UDP port 10023. Initial mixer IP: `192.168.0.100`.

## Features implemented
- 32 channel strips, landscape layout, horizontally scrollable for phones/tablets
- Channel names, fader read/write, channel ON/MUTE read/write
- `/xinfo` discovery, `/xremote` subscription every 8 seconds, periodic polling for resync
- Read-only on launch. Enable WRITE explicitly to send control changes.
- User-editable IP and local preferences

**Not yet implemented:** meters, EQ, dynamics, sends, DCA, FX, solo, channel colors from mixer, full reconnect/backoff, professional fader ergonomics. Processing header is a placeholder.

## Build using Android only (GitHub Actions)
1. On Android, create a new GitHub repository.
2. Upload **the contents** of this project folder to repository root, including `.github/workflows/android.yml` (GitHub web upload may hide dotfolders; use a mobile Git client or create workflow file manually).
3. In GitHub repository, go to **Actions > Build Android APK > Run workflow**. Pushing to main also triggers build.
4. After a successful run, download artifact `M32FOHControl-debug-apk`, unzip it, then install `app-debug.apk` on Android.
5. Connect phone/tablet to the same router/network as M32. Enter its IP, tap CONNECT, confirm channel names/faders are synchronized. Only then enable WRITE, ideally with PA muted or during a rehearsal.

GitHub Actions needs network access to download Gradle and Android build dependencies. This project has not been compiled or tested on an actual M32 in this environment. Build configuration and OSC behavior must be validated.

## OSC mapping
- `/ch/01/mix/fader`: OSC float 0.0–1.0 (nonlinear console fader scale)
- `/ch/01/mix/on`: OSC int 1 = on/unmuted, 0 = off/muted
- `/ch/01/config/name`: OSC string
- `/xremote`: subscription keepalive

## Limitations and safety
No authentication/encryption on OSC. Use trusted LAN or secure VPN; never expose UDP 10023 directly to the Internet. The app uses targetSdk 28 for a simple dependency-free prototype; raise it and update behavior before distribution. Do not rely on this prototype for live-show-critical operation.
