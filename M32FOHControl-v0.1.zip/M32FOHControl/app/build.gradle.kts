plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.kai.m32"; compileSdk = 35
    defaultConfig { applicationId = "com.kai.m32"; minSdk = 26; targetSdk = 28; versionCode = 1; versionName = "0.1" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
