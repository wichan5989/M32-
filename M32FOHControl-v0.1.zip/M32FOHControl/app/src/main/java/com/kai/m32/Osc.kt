package com.kai.m32

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

object Osc {
    private fun padded(s: String): ByteArray {
        val raw = s.toByteArray(StandardCharsets.UTF_8)
        val len = (raw.size + 4) and -4
        return ByteArray(len).also { System.arraycopy(raw, 0, it, 0, raw.size) }
    }
    fun packet(address: String, value: Any? = null): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(padded(address))
        when (value) {
            is Float -> { out.write(padded(",f")); out.write(ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putFloat(value).array()) }
            is Int -> { out.write(padded(",i")); out.write(ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(value).array()) }
            is String -> { out.write(padded(",s")); out.write(padded(value)) }
            null -> out.write(padded(","))
            else -> error("Unsupported OSC type")
        }
        return out.toByteArray()
    }
    data class Message(val address: String, val value: Any?)
    fun decode(data: ByteArray, length: Int): Message? = try {
        var pos = 0
        fun readString(): String {
            val start = pos
            while (pos < length && data[pos].toInt() != 0) pos++
            if (pos >= length) throw IllegalArgumentException("OSC string not terminated")
            val s = String(data, start, pos - start, StandardCharsets.UTF_8)
            pos = (pos + 4) and -4
            s
        }
        val address = readString()
        if (!address.startsWith("/")) return null
        val tags = readString()
        val value: Any? = when (tags.getOrNull(1)) {
            'f' -> { if (pos + 4 > length) return null; ByteBuffer.wrap(data, pos, 4).order(ByteOrder.BIG_ENDIAN).float }
            'i' -> { if (pos + 4 > length) return null; ByteBuffer.wrap(data, pos, 4).order(ByteOrder.BIG_ENDIAN).int }
            's' -> readString()
            else -> null
        }
        Message(address, value)
    } catch (_: Exception) { null }
}
