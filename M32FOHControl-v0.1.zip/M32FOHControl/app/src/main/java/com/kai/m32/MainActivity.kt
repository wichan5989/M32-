package com.kai.m32

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private var client: M32Client? = null
    private val faders = FloatArray(32) { 0.75f }
    private val enabled = BooleanArray(32) { true }
    private val names = Array(32) { "CH %02d".format(Locale.US, it + 1) }
    private val sliders = arrayOfNulls<SeekBar>(32)
    private val mutes = arrayOfNulls<Button>(32)
    private val labels = arrayOfNulls<TextView>(32)
    private var writeEnabled = false
    private lateinit var status: TextView
    private lateinit var ip: EditText
    private var syncing = false
    private val bg = Color.rgb(12, 15, 22)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.statusBarColor = bg; window.navigationBarColor = bg
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12, 8, 12, 8); setBackgroundColor(Color.rgb(25, 30, 42)) }
        toolbar.addView(text("M32  FOH", 19, Color.WHITE), LinearLayout.LayoutParams(0, 48, 1f))
        ip = EditText(this).apply { setSingleLine(); setText(prefs.getString("ip", "192.168.0.100")); setTextColor(Color.WHITE); textSize = 14f; inputType = InputType.TYPE_CLASS_TEXT; minWidth = 160 }
        toolbar.addView(ip)
        val connect = button("CONNECT", Color.rgb(32, 101, 148)) { connectNow() }
        toolbar.addView(connect)
        val write = Switch(this).apply { text = " WRITE"; setTextColor(Color.WHITE); isChecked = false; setOnCheckedChangeListener { _, checked -> writeEnabled = checked; Toast.makeText(this@MainActivity, if (checked) "Write enabled: live mixer controls" else "Read-only mode", Toast.LENGTH_SHORT).show() } }
        toolbar.addView(write)
        root.addView(toolbar)
        status = text("Disconnected • READ ONLY by default", 12, Color.rgb(145, 190, 220)).apply { setPadding(16, 4, 8, 4) }
        root.addView(status)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(12, 6, 12, 6) }
        top.addView(text("SELECTED CHANNEL", 13, Color.rgb(135, 185, 230)), LinearLayout.LayoutParams(0, 52, 1f))
        top.addView(text("GATE  |  EQ  |  COMP  |  SENDS", 15, Color.rgb(175, 190, 210)), LinearLayout.LayoutParams(0, 52, 2f))
        top.addView(text("Processing controls: next release", 12, Color.rgb(110, 135, 160)), LinearLayout.LayoutParams(0, 52, 2f))
        root.addView(top)
        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = true; fillViewport = true }
        val strips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 0, 8, 0) }
        for (i in 0 until 32) {
            val index = i
            val strip = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(3, 4, 3, 4); setBackgroundColor(if (i % 2 == 0) Color.rgb(24, 29, 39) else Color.rgb(19, 24, 34)) }
            val name = text(names[i], 12, Color.WHITE).apply { gravity = Gravity.CENTER; setBackgroundColor(channelColor(i)); setPadding(2, 9, 2, 9) }
            labels[i] = name
            strip.addView(name, LinearLayout.LayoutParams(68, 40))
            val mute = button("MUTE", Color.rgb(65, 43, 47)) { if (writeEnabled) client?.send(path(index, "mix/on"), if (enabled[index]) 0 else 1) else Toast.makeText(this, "Enable WRITE to control mixer", Toast.LENGTH_SHORT).show() }
            mutes[i] = mute
            strip.addView(mute, LinearLayout.LayoutParams(68, 44))
            val level = text("--", 12, Color.rgb(210, 220, 230)).apply { gravity = Gravity.CENTER }
            strip.addView(level, LinearLayout.LayoutParams(68, 30))
            val slider = SeekBar(this).apply {
                max = 1000; progress = (faders[index] * 1000).roundToInt(); rotation = -90f
                progressTintList = android.content.res.ColorStateList.valueOf(channelColor(index))
                thumbTintList = android.content.res.ColorStateList.valueOf(Color.LTGRAY)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onStartTrackingTouch(s: SeekBar?) { }
                    override fun onStopTrackingTouch(s: SeekBar?) { }
                    override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser && !syncing) {
                            if (writeEnabled) client?.send(path(index, "mix/fader"), progress / 1000f)
                            else { syncing = true; s?.progress = (faders[index] * 1000).roundToInt(); syncing = false }
                        }
                    }
                })
            }
            sliders[i] = slider
            val holder = FrameLayout(this)
            holder.addView(slider, FrameLayout.LayoutParams(330, 68, Gravity.CENTER).apply { leftMargin = -130; rightMargin = -130 })
            strip.addView(holder, LinearLayout.LayoutParams(68, 345))
            strip.addView(text("CH %02d".format(Locale.US, i + 1), 11, Color.LTGRAY).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(68, 32))
            strips.addView(strip, LinearLayout.LayoutParams(74, LinearLayout.LayoutParams.MATCH_PARENT))
        }
        scroller.addView(strips)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("CH 1–32   •   Swipe horizontally   •   OSC UDP :10023   •   v0.1", 12, Color.rgb(115, 140, 160)).apply { setPadding(14, 6, 0, 6) })
        setContentView(root)
        connectNow()
    }
    private fun connectNow() {
        client?.stop()
        val host = ip.text.toString().trim()
        getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putString("ip", host).apply()
        status.text = "Connecting $host • ${if (writeEnabled) "WRITE" else "READ ONLY"}"
        client = M32Client(host, { msg -> handle(msg) }, { s -> status.text = s + if (writeEnabled) " • WRITE" else " • READ ONLY" }).also { it.start() }
    }
    private fun handle(msg: Osc.Message) {
        if (msg.address == "/xinfo") { status.text = "M32 responding • ${ip.text} • ${if (writeEnabled) "WRITE" else "READ ONLY"}"; return }
        val match = Regex("^/ch/(\\d{2})/(mix/fader|mix/on|config/name)$").matchEntire(msg.address) ?: return
        val index = (match.groupValues[1].toIntOrNull() ?: return) - 1
        if (index !in 0..31) return
        when (match.groupValues[2]) {
            "mix/fader" -> { val v = (msg.value as? Number)?.toFloat()?.coerceIn(0f, 1f) ?: return; faders[index] = v; syncing = true; sliders[index]?.progress = (v * 1000).roundToInt(); syncing = false }
            "mix/on" -> { enabled[index] = (msg.value as? Number)?.toInt() == 1; mutes[index]?.setBackgroundColor(if (enabled[index]) Color.rgb(65,43,47) else Color.rgb(185,45,50)) }
            "config/name" -> { names[index] = (msg.value as? String)?.ifBlank { "CH %02d".format(Locale.US,index+1) } ?: return; labels[index]?.text = names[index] }
        }
    }
    private fun path(i: Int, suffix: String) = "/ch/%02d/%s".format(Locale.US, i + 1, suffix)
    private fun channelColor(i: Int) = when (i % 8) { 0,1 -> Color.rgb(177,146,39); 2,3 -> Color.rgb(35,137,157); 4,5 -> Color.rgb(39,147,78); else -> Color.rgb(162,62,76) }
    private fun text(s: String, size: Int, color: Int) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); gravity = Gravity.CENTER_VERTICAL; typeface = Typeface.DEFAULT_BOLD }
    private fun button(s: String, color: Int, onClick: () -> Unit) = Button(this).apply { text = s; textSize = 10f; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(color); setOnClickListener { onClick() } }
    override fun onDestroy() { client?.stop(); super.onDestroy() }
}
