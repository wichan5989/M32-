package com.kai.m32

import android.os.Handler
import android.os.Looper
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicBoolean

class M32Client(private val host: String, private val onMessage: (Osc.Message) -> Unit, private val onStatus: (String) -> Unit) {
    private val running = AtomicBoolean(false)
    private val main = Handler(Looper.getMainLooper())
    private var socket: DatagramSocket? = null
    private var worker: Thread? = null
    private var lastRx = 0L
    fun start() {
        if (!running.compareAndSet(false, true)) return
        worker = Thread {
            try {
                val address = InetAddress.getByName(host)
                val s = DatagramSocket()
                socket = s
                s.soTimeout = 250
                fun sendDirect(bytes: ByteArray) = s.send(DatagramPacket(bytes, bytes.size, address, 10023))
                var refresh = 0L
                var keepAlive = 0L
                val buffer = ByteArray(4096)
                main.post { onStatus("Connecting $host") }
                while (running.get()) {
                    val now = System.currentTimeMillis()
                    if (now - keepAlive > 8000) { sendDirect(Osc.packet("/xremote")); sendDirect(Osc.packet("/xinfo")); keepAlive = now }
                    if (now - refresh > 2500) {
                        for (ch in 1..32) {
                            val id = "%02d".format(java.util.Locale.US, ch)
                            sendDirect(Osc.packet("/ch/$id/mix/fader"))
                            sendDirect(Osc.packet("/ch/$id/mix/on"))
                            sendDirect(Osc.packet("/ch/$id/config/name"))
                        }
                        refresh = now
                    }
                    try {
                        val p = DatagramPacket(buffer, buffer.size)
                        s.receive(p)
                        if (p.address != address) continue
                        lastRx = System.currentTimeMillis()
                        Osc.decode(p.data, p.length)?.let { msg -> main.post { onMessage(msg) } }
                    } catch (_: SocketTimeoutException) { }
                    if (now - lastRx > 5000) main.post { onStatus("Waiting for M32 • $host") }
                }
            } catch (e: Exception) { main.post { onStatus("Network error: ${e.message}") } }
            finally { socket?.close(); socket = null; running.set(false) }
        }.also { it.start() }
    }
    fun send(path: String, value: Any) {
        val bytes = Osc.packet(path, value)
        Thread {
            try { val s = socket ?: return@Thread; s.send(DatagramPacket(bytes, bytes.size, InetAddress.getByName(host), 10023)) }
            catch (_: Exception) { }
        }.start()
    }
    fun stop() { running.set(false); socket?.close(); worker?.interrupt() }
}
